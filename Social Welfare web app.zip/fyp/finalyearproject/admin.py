from django.contrib import admin

# Register your models here.
from .models import Post, Category, Staff, Comment, Client, Programme, ProgrammeType
admin.site.register(Post)
admin.site.register(Programme)
admin.site.register(ProgrammeType)
admin.site.register(Category)
admin.site.register(Staff)
admin.site.register(Comment)
admin.site.register(Client)



 
