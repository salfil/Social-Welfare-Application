from django  import forms
from .models import Post, Category, Comment, User, Programme, ProgrammeType
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm, UserChangeForm
from django.contrib.auth.models import User
from django import forms
from finalyearproject.models import Staff, Client

#choices=[('General', 'General'), ('mental health','mental health' ), ('career', 'career')]
choices = Category.objects.all().values_list('name', 'name')
choice_list=[]
programme_types = ProgrammeType.objects.all().values_list('type', 'type')
programme_types_list=[]

for programme in programme_types:
    programme_types_list.append(programme)

for choice in choices:
    choice_list.append(choice)

class ClientRegistrationForm(UserCreationForm):  # register customer
    username = forms.CharField(required=True, label="", widget=forms.TextInput(attrs={'placeholder': 'Enter your username'}))
    username.widget.attrs.update({'class': 'app-form-control'})

    email = forms.EmailField(required=True, label="", widget=forms.TextInput(attrs={'placeholder': 'Enter your email'}))
    email.widget.attrs.update({'class': 'app-form-control'})

    first_name = forms.CharField(label="", widget=forms.TextInput(attrs={'placeholder': 'Enter your first name'}))
    first_name.widget.attrs.update({'class': 'app-form-control'})

    last_name = forms.CharField(label="", widget=forms.TextInput(attrs={'placeholder': 'Enter your last name'}))
    last_name.widget.attrs.update({'class': 'app-form-control'})

    profile_pic = forms.ImageField(label="")
    profile_pic.widget.attrs.update({'class': 'app-form-control'})

    password1 = forms.CharField(label='', widget=forms.PasswordInput(attrs={'placeholder': 'Password'}))
    password1.widget.attrs.update({'class': 'app-form-control'})

    password2 = forms.CharField(label='', widget=forms.PasswordInput(attrs={'placeholder': 'Enter your password again'}))
    password2.widget.attrs.update({'class': 'app-form-control'})

    class Meta:
        model = User
        fields = ['username', 'email', 'first_name', 'last_name', 'profile_pic', 'password1', 'password2']

class ProgrammeForm(forms.ModelForm):
    class Meta:
        model = Programme
        fields = ('title', 'author', 'type', 'description', 'link')

        widgets = {
            'title': forms.TextInput(attrs={'class' : 'form-control'}),
            #'author': forms.Select(attrs={'class' : 'form-control'}),
            'author': forms.TextInput(attrs={'class' : 'form-control', 'value':'', 'id':'e', 'type':'hidden'}),
            'type': forms.Select(choices=programme_types_list,attrs={'class' : 'form-control'}),
            'description': forms.Textarea(attrs={'class': 'form-control'}),
            'link': forms.TextInput(attrs={'class' : 'form-control'}),
        }

class PostForm(forms.ModelForm):
    class Meta:
        model = Post
        fields = ('title', 'author','category', 'body', 'header_image')

        widgets = {
            'title': forms.TextInput(attrs={'class' : 'form-control'}),
            #'author': forms.Select(attrs={'class' : 'form-control'}),
            'author': forms.TextInput(attrs={'class' : 'form-control', 'value':'', 'id':'e', 'type':'hidden'}),
            'category': forms.Select(choices=choice_list,attrs={'class' : 'form-control'}),
            'body': forms.Textarea(attrs={'class': 'form-control'}),
        }

class PostEditForm(forms.ModelForm):
    class Meta:
        model = Post
        fields = ('title','category', 'body')

        widgets = {
            'title': forms.TextInput(attrs={'class' : 'form-control'}),
            #'author': forms.Select(attrs={'class' : 'form-control'}),
            #'author': forms.TextInput(attrs={'class' : 'form-control', 'value':'', 'id':'elder', 'type':'hidden'}),
            'category': forms.Select(choices=choice_list,attrs={'class' : 'form-control'}),
            'body': forms.Textarea(attrs={'class': 'form-control'}),
        }



class CommentForm(forms.ModelForm):
    class Meta:
        model = Comment
        fields = ('name', 'body')

        widgets = {
            'name': forms.TextInput(attrs={'class' : 'form-control'}),
            #'author': forms.Select(attrs={'class' : 'form-control'}),
            #'author': forms.TextInput(attrs={'class' : 'form-control', 'value':'', 'id':'elder', 'type':'hidden'}),
            #'category': forms.Select(choices=choice_list,attrs={'class' : 'form-control'}),
            'body': forms.Textarea(attrs={'class': 'form-control'}),
        }