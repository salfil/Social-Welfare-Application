from django.db import models
from django.contrib.auth.models import User
from django.urls import reverse
from ckeditor.fields import RichTextField
from datetime import datetime, date

class Staff(models.Model):
    user = models.OneToOneField(User, null=True, on_delete=models.CASCADE)
    speciality = models.CharField(max_length=255, blank=True)
    bio=models.TextField(null=True, blank=True)
    profile_pic = models.ImageField(null=True, blank=True, upload_to="images/profile")
    linkedin_url = models.CharField(max_length=255, null=True, blank=True)
    

    def __str__(self):
        return str(self.user)

    def get_absolute_url(self):
        return reverse('home')

class Client(models.Model):
    client = models.ForeignKey(User, null=True, on_delete=models.CASCADE)
    bio=models.TextField(null=True, blank=True)
    profile_pic = models.ImageField(null=True, blank=True, upload_to="images/profile")
    first_name = models.CharField(max_length=100, default='first_name')  # customer first name
    last_name = models.CharField(max_length=100, default='last_name')
    username = models.CharField(max_length=100, default='username')
    email = models.EmailField(max_length=100, blank=True)
    

    def __str__(self):
        return str(self.client.username)

    def get_absolute_url(self):
        return reverse('home')


class ProgrammeType(models.Model):
    type = models.CharField(max_length=255)

    def __str__(self):
        return self.type

class Programme(models.Model):
    title=models.CharField(max_length=255)
    type=models.CharField(max_length=255)
    description=models.CharField(max_length=255)
    link=models.CharField(max_length=255, null=True, blank=True)
    author = models.ForeignKey(User,on_delete=models.CASCADE)
    image=models.ImageField(null=True, blank=True, upload_to="images/")

    def __str__(self):
        return self.title
    
    def get_absolute_url(self):
        return reverse('home')
    

# Create your models here.
class Category(models.Model):
    name = models.CharField(max_length=255)

    def __str__(self):
        return self.name

    def get_absolute_url(self):
        return reverse('home')

class Post(models.Model):
    title = models.CharField(max_length=255)
    author = models.ForeignKey(User,on_delete=models.CASCADE)
    body = RichTextField(blank=True, null=True)
    header_image = models.ImageField(null=True, blank=True, upload_to="images/")
    #body=models.TextField()
    category = models.CharField(max_length=255, default='general')
    post_date = models.DateField(auto_now_add=True)
    likes = models.ManyToManyField(User, related_name='like_post')

    def __str__(self):
        return self.title + ' ' + str(self.author)

    def get_absolute_url(self):
        return reverse('home')

class Comment(models.Model):
    post = models.ForeignKey(Post, related_name="comments",on_delete=models.CASCADE)
    name = models.CharField(max_length=255)
    body = models.TextField()
    date_added = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return '%s -%s' % (self.post.title, self.name)



