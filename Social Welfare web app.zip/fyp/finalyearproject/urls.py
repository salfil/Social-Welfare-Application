"""fyp URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from . import views
from .views import HomeView, PostDetailView,AddPostView, CategoryView, CategoryListView, AddCommentView, UpdatePostView, DeletePostView, LikeView, register_client_view, AddProgrammeView, ProgrammesPageView, ProgrammeTypePageView, search_programmes, ProgrammeDetailView, AllProgrammesPageView

urlpatterns = [
    path('', HomeView.as_view(), name="home"),
    path('post/<int:pk>', PostDetailView.as_view(), name="post_detail"),
    path('programme/<int:pk>', ProgrammeDetailView.as_view(), name="programme_detail"),
    path('add_post/', AddPostView.as_view(), name="add_post" ),
    path('register/client',register_client_view , name="register_client" ),
    path('category/<str:cats>/', CategoryView, name='category'),
    path('category_list/', CategoryListView, name='category_list'),
    path('post/<int:pk>/comment/', AddCommentView.as_view(), name="add_comment"),
    path('post/edit/<int:pk>', UpdatePostView.as_view(), name='update_post'), 
    path('post/<int:pk>/delete', DeletePostView.as_view(), name='delete_post'), 
    path('like/<int:pk>', LikeView, name='like_post'),
    path('add_programme', AddProgrammeView.as_view(), name='add_programme'),
    path('programmes', ProgrammesPageView, name='programmesPage'),
    path('type/<str:types>/', ProgrammeTypePageView, name='programme_type'),
    path('search_programmes', search_programmes, name='search_programmes'),
    path('all_programmes', AllProgrammesPageView, name='all_programmes'),


]
