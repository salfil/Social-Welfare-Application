from django.shortcuts import render, get_object_or_404, redirect
from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView
from .models import Post, Category,  Comment, Client, Staff, Programme, ProgrammeType
from .forms import PostForm, CommentForm, PostEditForm, ClientRegistrationForm, ProgrammeForm
from django.contrib.auth.models import User, Group
from django.contrib import messages
from django.urls import reverse_lazy, reverse
from django.http import HttpResponseRedirect
# Create your views here.

#def home(request):
#    return render(request, 'home.html', {})
def LikeView(request, pk):
    post = get_object_or_404(Post, id=request.POST.get('post_id'))
    post.likes.add(request.user)
    return HttpResponseRedirect(reverse('post_detail'), 
    args=[str(pk)])

class HomeView(ListView):
    model = Post
    template_name='home.html'
    #ordering = ['-id']
    ordering = ['-post_date']
    cats=Category.objects.all()

    def get_context_data(self, *args, **kwargs):
        cat_menu = Category.objects.all()
        context = super(HomeView, self).get_context_data(*args, **kwargs)
        context["cat_menu"] = cat_menu
        return context

def register_client_view(request):
    if request.method=="POST":
        registration_form = ClientRegistrationForm(request.POST, request.FILES)
        if registration_form.valid():
            new_user = User.objects.create_user(username=registration_form.cleaned_data.get('username'),
                                                    email=registration_form.cleaned_data.get('email'),
                                                    password=registration_form.cleaned_data.get(
                                                        'password1'))  # create use
            c = Client(client=new_user,
                             first_name=registration_form.cleaned_data.get('first_name'),
                             last_name=registration_form.cleaned_data.get('last_name'),
                             profile_pic=request.FILES['profile_pic'],
                             bio=registration_form.cleaned_data.get('last_name'),

                             )  # create customer
            c.save()

            group = Group.objects.get_or_create(name='client')  # add user to patient group
            group[0].user_set.add(new_user)

            messages.add_message(request, messages.INFO, 'Registration successful!')
            return redirect('home')
        else:
            print(registration_form.errors)
    else:
        registration_form = ClientRegistrationForm()
    return render(request, 'register_client.html', {'registration_form': registration_form})


def CategoryListView(request):
    cat_menu_list = Category.objects.all()
    return render(request, 'category_list.html', {'cat_menu_list': cat_menu_list,})


def CategoryView(request, cats):
    category_posts = Post.objects.filter(category=cats)
    return render(request, 'categories.html', {'cats': cats, 
    'category_posts':category_posts})

def ProgrammeTypePageView(request, types):
    programme_types = Programme.objects.filter(type=types)
    return render(request, 'programme_types.html', {'types': types, 
    'programme_types':programme_types})
    
def ProgrammesPageView(request):
    programmes= ProgrammeType.objects.all()
    return render(request, 'programmes.html', {'programmes': programmes}) 

def AllProgrammesPageView(request):
    all_programmes= Programme.objects.all()
    return render(request, 'all_programmes.html', {'programmes': all_programmes})

def search_programmes(request):
    if request.method == "POST":
        searched = request.POST.get('searched', "hello")
        searched = request.POST['searched']
        programmes=Programme.objects.filter(title__contains=searched)
        return render(request, 'search_programmes.html', {'searched': searched, 
        'programmes':programmes})
    else:
        return render(request, 'search_programmes.html', {})

class ProgrammeDetailView(DetailView):
    model = Programme
    template_name = 'programme_detail.html'

    def get_context_data(self, *args, **kwargs):
        programme_menu = Programme.objects.all()
        context = super(ProgrammeDetailView, self).get_context_data(*args, **kwargs)
        context["programme_menu"] = programme_menu
        return context

class PostDetailView(DetailView):
    model = Post
    template_name = 'post_detail.html'

    def get_context_data(self, *args, **kwargs):
        cat_menu = Category.objects.all()
        context = super(PostDetailView, self).get_context_data(*args, **kwargs)
        context["cat_menu"] = cat_menu
        return context

class AddProgrammeView(CreateView):
    model = Programme
    form_class=ProgrammeForm
    template_name = 'add_programme.html'


class AddPostView(CreateView):
    model = Post
    form_class=PostForm
    template_name ='add_post.html'
    #fields = '__all__'
    #fields = ('title', 'body') for just a few attributes. 


class UpdatePostView(UpdateView):
    model = Post
    form_class = PostEditForm
    template_name = 'update_post.html'
    #fields=['title', 'body', 'category']

class DeletePostView(DeleteView):
    model = Post
    template_name = 'delete_post.html'
    #fields=['title', 'body', 'category']

    success_url = reverse_lazy("home")

class AddCommentView(CreateView):
    model = Comment
    form_class=CommentForm
    template_name ='add_comment.html'
    
    #fields = ('title', 'body') for just a few attributes.

    def form_valid(self, form):
        form.instance.post_id = self.kwargs['pk']
        return super().form_valid(form)

    success_url = reverse_lazy('home')
