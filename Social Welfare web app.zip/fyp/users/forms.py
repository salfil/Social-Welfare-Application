from django.contrib.auth.forms import UserCreationForm, UserChangeForm
from django.contrib.auth.models import User
from django import forms
from finalyearproject.models import Staff, Client

class ProfilePageForm(forms.ModelForm):

    class Meta:
        model = Staff
        fields = ('bio', 'profile_pic', 'speciality', 'linkedin_url')
        widgets = {
            'bio': forms.TextInput(attrs={'class' : 'form-control'}),
            #'author': forms.Select(attrs={'class' : 'form-control'}),
            #'profile_pic': forms.TextInput(attrs={'class' : 'form-control'}),
            'speciality': forms.TextInput(attrs={'class' : 'form-control'}),
            'linkedin_url': forms.TextInput(attrs={'class': 'form-control'}),

        }

'''class ClientRegistrationForm(UserCreationForm):  # register customer
    username = forms.CharField(required=True, label="", widget=forms.TextInput(attrs={'placeholder': 'Enter your username'}))
    username.widget.attrs.update({'class': 'app-form-control'})

    email = forms.EmailField(required=True, label="", widget=forms.TextInput(attrs={'placeholder': 'Enter your email'}))
    email.widget.attrs.update({'class': 'app-form-control'})

    first_name = forms.CharField(label="", widget=forms.TextInput(attrs={'placeholder': 'Enter your first name'}))
    first_name.widget.attrs.update({'class': 'app-form-control'})

    last_name = forms.CharField(label="", widget=forms.TextInput(attrs={'placeholder': 'Enter your last name'}))
    last_name.widget.attrs.update({'class': 'app-form-control'})

    profile_pic = forms.ImageField(label="")
    profile_pic.widget.attrs.update({'class': 'app-form-control'})

    password1 = forms.CharField(label='', widget=forms.PasswordInput(attrs={'placeholder': 'Password'}))
    password1.widget.attrs.update({'class': 'app-form-control'})

    password2 = forms.CharField(label='', widget=forms.PasswordInput(attrs={'placeholder': 'Enter your password again'}))
    password2.widget.attrs.update({'class': 'app-form-control'})

    class Meta:
        model = User
        fields = ['username', 'email', 'first_name', 'last_name', 'profile_pic', 'password1', 'password2']'''
        

class SignUpForm(UserCreationForm):
    email=forms.EmailField(widget=forms.EmailInput(attrs={'class' : 'form-control'}))
    first_name=forms.CharField(max_length=100, widget=forms.TextInput(attrs={'class' : 'form-control'}))
    last_name=forms.CharField(max_length=100, widget=forms.TextInput(attrs={'class' : 'form-control'}))

    class Meta:
        model = User
        fields = ('username', 'first_name', 'last_name', 'email', 'password1', 'password2')


    def __init__(self, *args, **kwargs):
        super(SignUpForm, self).__init__(*args, **kwargs)
        self.fields['username'].widget.attrs['class']= 'form-control'
        self.fields['password1'].widget.attrs['class']= 'form-control'
        self.fields['password2'].widget.attrs['class']= 'form-control'



class EditProfileForm(UserChangeForm):
    email=forms.EmailField(widget=forms.EmailInput(attrs={'class' : 'form-control'}))
    first_name=forms.CharField(max_length=100, widget=forms.TextInput(attrs={'class' : 'form-control'}))
    last_name=forms.CharField(max_length=100, widget=forms.TextInput(attrs={'class' : 'form-control'}))
    username=forms.CharField(max_length=100, widget=forms.TextInput(attrs={'class' : 'form-control'}))
    


    class Meta:
        model = User
        fields = ('username', 'first_name', 'last_name', 'email')
